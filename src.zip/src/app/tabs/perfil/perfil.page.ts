import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { IUsuario } from 'src/Interfaces/usuarios'; 
import { UsuariosService } from 'src/app/services/usuarios.service';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
})
export class PerfilPage implements OnInit {

  nombre: string = '';        
  correo: string = '';        
  telefono: string = ''; 
  rut: string='';     
  usuario: IUsuario | null = null;

  constructor(
    private router: Router,
    private alertcontroller: AlertController,
    private usuarioservice: UsuariosService 
  ) { }

  ngOnInit(): void {
    this.cargarUsuario(); // Mueve la lógica de carga del usuario a esta función
  }

  // Se ejecuta cada vez que se entra a la página o pestaña
  ionViewWillEnter(): void {
    this.cargarUsuario(); // Carga los datos de usuario al entrar
  }

  cargarUsuario(): void {
    this.usuario = JSON.parse(localStorage.getItem('user') || '{}');

    if (!this.usuario || !this.usuario.usuario) {
      this.router.navigate(['/login']);
    } else {
      this.nombre = this.usuario.usuario;
      this.correo = this.usuario.email;
      this.telefono = this.usuario.cel;
      this.rut = this.usuario.rut;
    }
  }
  

  // Método para mostrar el menú
  mostrarMenu() {
    console.log('Aquí puedes implementar la lógica para mostrar un menú si es necesario.');
  }

  // perfil.page.ts
editar() {
  this.router.navigate(['/detalle-perfil'], {
    queryParams: { 
      usuario: JSON.stringify(this.usuario)
    }
  });
}

  
  

  async cerrar() {
    const alert = await this.alertcontroller.create({
      header: 'Confirmar',
      message: '¿Estás seguro de que quieres cerrar sesión?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
        },
        {
          text: 'Cerrar Sesión',
          handler: () => {
            localStorage.removeItem('user');
            this.router.navigate(['/login']);
          },
        },
      ],
    });
    await alert.present();
  }
  

  // Método para consumir una API (similar al ejemplo de tu profesor)
  CargarApi() {
    this.usuarioservice.getUsuarios().subscribe(resp => {
      console.log(resp);
    });
  }
}
