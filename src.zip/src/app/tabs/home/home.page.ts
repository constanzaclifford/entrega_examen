import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  images: string[] = [
    'assets/Finanzas.jpg',
    'assets/Historia.jpg',
    'assets/Math.jpg'
  ];
  constructor(private alertcontroller: AlertController,
              private router: Router, private menucontroller: MenuController
  ) { }

  ngOnInit() {
  }

  generar() {

    this.router.navigate(['/clases'])

  }

  mostrarMenu(){
    this.menucontroller.enable(true);
    this.menucontroller.open('first');
  }

  
  
  

  justificar() {

    this.router.navigate(['/justificacion'])
  }
}
