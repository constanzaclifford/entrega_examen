import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IJustificacion, IJustificacionPost } from 'src/Interfaces/justificacion';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ServiceJustificar {
  private apiUrl = `${environment.apiUrl}/justificaciones`;

  constructor(private httpclient: HttpClient) {}

  // Obtener todas las justificaciones
  getJustificaciones(): Observable<IJustificacion[]> {
    return this.httpclient.get<IJustificacion[]>(this.apiUrl);
  }

  // JustificacionesService

  getJustificacionesByUsuario(usuarioId: number): Observable<IJustificacion[]> {
    return this.httpclient.get<IJustificacion[]>(`${environment.apiUrl}/justificaciones/?usuarioId=${usuarioId}`);
  }


  // Crear nueva justificación
  postJustificacion(newJustificacion: IJustificacionPost): Observable<IJustificacion> {
    return this.httpclient.post<IJustificacion>(this.apiUrl, newJustificacion);
  }

  // Método para eliminar una justificación
  deleteJustificacion(id: number): Observable<void> {
    return this.httpclient.delete<void>(`${environment.apiUrl}/justificaciones/${id}`);
  }
}
