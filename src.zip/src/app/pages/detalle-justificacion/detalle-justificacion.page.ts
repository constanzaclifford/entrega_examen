import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IJustificacion } from 'src/Interfaces/justificacion';
import { ServiceJustificar } from 'src/app/services/servicejustificar.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-detalle-justificacion',
  templateUrl: './detalle-justificacion.page.html',
  styleUrls: ['./detalle-justificacion.page.scss'],
})
export class DetalleJustificacionPage implements OnInit {
  justificacion: IJustificacion | null = null; // Inicializado como null

  constructor(
    private activaterouter: ActivatedRoute,
    private router: Router,
    private justificacionService: ServiceJustificar,
    private alertController: AlertController // Agrega el AlertController
  ) {
    this.activaterouter.queryParams.subscribe(param => {
      this.justificacion = JSON.parse(param['justificacion']);
    });
  }
  
  ngOnInit() {}

  regresar() {
    this.router.navigate(['/justificacion']);
  }

  async eliminarJustificacion() {
    const alert = await this.alertController.create({
      header: 'Confirmación',
      message: '¿Estás seguro de que deseas eliminar esta justificación?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          handler: () => {
            console.log('Eliminación cancelada');
          }
        },
        {
          text: 'Eliminar',
          handler: () => {
            if (this.justificacion) {
              this.justificacionService.deleteJustificacion(this.justificacion.id).subscribe(
                async () => {
                  console.log('Justificación eliminada');
                  const successAlert = await this.alertController.create({
                    header: 'Éxito',
                    message: 'Justificación eliminada correctamente. LOS CAMBIOS SE VERAN REFLEJADOS AL ACTUALIZAR (F5)',
                    buttons: ['Aceptar']
                  });
                  await successAlert.present();
                  this.regresar(); // Regresar a la lista de justificaciones
                },
                error => {
                  console.error('Error al eliminar la justificación', error);
                  this.mostrarError('No se pudo eliminar la justificación. Intente nuevamente.');
                }
              );
            }
          }
        }
      ]
    });
    await alert.present();
  }

  mostrarError(mensaje: string) {
    // Implementa la función para mostrar mensajes de error (puedes usar un Toast o una alerta)
    console.error(mensaje);
    alert(mensaje); // Simple alert for demonstration
  }
}
